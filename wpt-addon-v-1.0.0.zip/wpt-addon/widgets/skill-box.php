<?php
namespace Elementor;

class Skill_Box extends Widget_Base {

    public function get_name() {
        return  'skill-box-id';
    }

    public function get_title() {
        return esc_html__( 'Skill Box', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-info-box';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'skill_box_content_section',
			[
				'label' => esc_html__( 'Skill Box', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // Image Control
        $this->add_control(
			'skill_box_image',
			[
				'label' => esc_html__( 'Choose Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        // Title Control
        $this->add_control(
			'skill_box_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Type your title here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,

			]
		);
        // Description Control
        $this->add_control(
			'skill_box_desc',
			[
				'label' => esc_html__( 'Description', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( 'Type your description here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your description here', 'wpt-addon' ),
			]
		);
        // Button Control
        $this->add_control(
			'skill_box_btn_title',
			[
				'label' => esc_html__( 'Button Text', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read More', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'skill_box_popup_section',
			[
				'label' => esc_html__( 'Skill Box Popup', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // Top Image Control
        $this->add_control(
			'skill_box_popup_top_image',
			[
				'label' => esc_html__( 'Choose Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        // Popup Main Title Control
        $this->add_control(
			'skill_box_popup_main_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Type your title here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,
			]
		);
        // Protfolio Image Control
        $this->add_control(
			'skill_box_popup_port_image',
			[
				'label' => esc_html__( 'Choose Protfolio Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        // Description Control
        $this->add_control(
			'skill_box_port_desc',
			[
				'label' => esc_html__( 'Protfolio Description', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( 'Type your description here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your description here', 'wpt-addon' ),
			]
		);
        // Popup link Title Control
        $this->add_control(
			'skill_box_popup_link_title',
			[
				'label' => esc_html__( 'Link Text', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'www.example.com', 'wpt-addon' ),
				'placeholder' => esc_html__( 'www.example.com', 'wpt-addon' ),
                'label_block' => true,
			]
		);
        // Popup link url Control
        $this->add_control(
			'skill_box_popup_link_website_link',
			[
				'label' => esc_html__( 'Website Link', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'wpt-addon' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
        // Popup link Icon
        $this->add_control(
			'skill_box_popup_link_icon',
			[
				'label' => esc_html__( 'Fontawesome Icon Classes', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'fa-solid fa-globe', 'wpt-addon' ),
				'placeholder' => esc_html__( 'fa-solid fa-globe', 'wpt-addon' ),
                'label_block' => true,
			]
		);
        // Popup link Services Title Control
        $this->add_control(
			'skill_box_popup_service_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Services', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Services', 'wpt-addon' ),
                'label_block' => true,
			]
		);
        // Services Name Control
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'skill_box_port_service_list_name',
			[
				'label' => esc_html__( 'Services Name', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Web Design', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Web Design', 'wpt-addon' ),
                'label_block' => true,
			]
		);
		$this->add_control(
			'skill_box_port_service_list',
			[
				'label' => esc_html__( 'Service List', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'skill_box_port_service_list_name' => esc_html__( 'Web Design', 'wpt-addon' ),
					],
					[
						'skill_box_port_service_list_name' => esc_html__( 'Graphics Design', 'wpt-addon' ),
					],
				],
				'title_field' => '{{{ skill_box_port_service_list_name }}}',
			]
		);


        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //skill box content Style Settings
        $this->start_controls_section(
			'skill_box_content_section_style',
			[
				'label' => esc_html__( 'Skill Box Content', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box wrapper background
		$this->add_control(
			'skill_box_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap' => 'background: {{VALUE}}',
				],
				'default' => '#12141C'
			]
		);
		//skill box content Padding
		$this->add_control(
			'skill_box_content_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .skill-box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 50,
					'right' => 50,
					'bottom' => 50,
					'left' => 50,
				],
			]
		);
		$this->end_controls_section();
		//skill box content Style Settings
        $this->start_controls_section(
			'skill_box_content_img_icon_style',
			[
				'label' => esc_html__( 'Skill Box Image Icon', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box content Image Icon Width
		$this->add_control(
			'skill_box_content_img_icon_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 56,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		//skill box content Image Icon Height
		$this->add_control(
			'skill_box_content_img_icon_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 61,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		//skill box content Image Icon Margin
		$this->add_control(
			'skill_box_content_img_icon_space_bottom',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .img' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box content Style Settings
        $this->start_controls_section(
			'skill_box_content_title_style',
			[
				'label' => esc_html__( 'Skill Box Title', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box content Title Color
		$this->add_control(
			'skill_box_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .title h3' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
		//skill box content Title Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_content_title_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .title h3',
			]
		);
		//skill box content Title Space Between
		$this->add_control(
			'skill_box_content_title_space_bottom',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .title h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box content Description Style
        $this->start_controls_section(
			'skill_box_content_desc_style',
			[
				'label' => esc_html__( 'Skill Box Description', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box content Desc Color
		$this->add_control(
			'skill_box_content_desc_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .desc p' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
		//skill box content Desc Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_content_desc_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .desc p',
			]
		);
		//skill box content Desc Space Between
		$this->add_control(
			'skill_box_content_desc_space_bottom',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .desc p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box content Button Style
        $this->start_controls_section(
			'skill_box_content_button_style',
			[
				'label' => esc_html__( 'Skill Box Button', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box content Button Color
		$this->add_control(
			'skill_box_content_button_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .wtad-skill-button .wtad-btn' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
		//skill box content Button Border Color
		$this->add_control(
			'skill_box_content_button_border_color',
			[
				'label' => esc_html__( 'Border Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .wtad-skill-button .wtad-btn::before' => 'background: {{VALUE}}',
				],
				'default' => '#F26C4F'
			]
		);
		//skill box content Button Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_content_button_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .wtad-skill-button .wtad-btn',
			]
		);
		$this->end_controls_section();


		//skill box content Style Settings
        $this->start_controls_section(
			'skill_box_popup_header_style',
			[
				'label' => esc_html__( 'Skill Box Popup Header', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Header Background
		$this->add_control(
			'skill_box_popup_header_bckground',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header' => 'background: {{VALUE}}',
				],
				'default' => '#F8F9FA'
			]
		);
		//skill box Popup Header Padding
		$this->add_control(
			'skill_box_popup_header_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 25,
					'right' => 50,
					'bottom' => 25,
					'left' => 50,
				],
			]
		);
        $this->end_controls_section();
		//skill box Popup Header Image Icon Style Settings
        $this->start_controls_section(
			'skill_box_popup_header_img_style',
			[
				'label' => esc_html__( 'Skill Box Popup Header Image', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Header Background
		$this->add_control(
			'skill_box_popup_header_img_bckground',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .img' => 'background: {{VALUE}}',
				],
				'default' => '#343A40'
			]
		);
		//skill box Popup Header Img Width
		$this->add_control(
			'skill_box_popup_header_img_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		//skill box Popup Header Img Height
		$this->add_control(
			'skill_box_popup_header_img_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		//skill box Popup Header Img Padding
		$this->add_control(
			'skill_box_popup_header_img_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 30,
					'right' => 20,
					'bottom' => 10,
					'left' => 20,
				],
			]
		);
        $this->end_controls_section();
		//skill box Popup Header Title Color
        $this->start_controls_section(
			'skill_box_popup_header_title_style',
			[
				'label' => esc_html__( 'Popup Header Title', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Header Title Color
		$this->add_control(
			'skill_box_popup_header_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .title h3' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
		//skill box Popup Header Title Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_popup_header_title_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .title h3',
			]
		);
		//skill box Popup Header Title Space Between
		$this->add_control(
			'skill_box_popup_header_title_space_top',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 105,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-header .title' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box Popup Content Desc Style
        $this->start_controls_section(
			'skill_box_popup_content_desc_style',
			[
				'label' => esc_html__( 'Popup Content Description', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Content Desc Color
		$this->add_control(
			'skill_box_popup_content_desc_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .desc p' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
		//skill box Popup Content Desc Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_popup_content_desc_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .desc p',
			]
		);
		$this->end_controls_section();
		//skill box Popup Content Link Style
        $this->start_controls_section(
			'skill_box_popup_content_link_style',
			[
				'label' => esc_html__( 'Popup Content Link', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Content Link Color
		$this->add_control(
			'skill_box_popup_content_link_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .link a' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
		//skill box Popup Content Desc Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_popup_content_link_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .link a',
			]
		);
		//skill box Popup Content Desc Space Between
		$this->add_control(
			'skill_box_popup_content_link_space_bottom',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .link' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box Popup Footer Title Style
        $this->start_controls_section(
			'skill_box_popup_footer_title_style',
			[
				'label' => esc_html__( 'Popup Footer Title', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Footer Title Color
		$this->add_control(
			'skill_box_popup_footer_title_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .title h3' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
		//skill box Popup Footer Title Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_popup_footer_title_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .title h3',
			]
		);
		//skill box Popup Footer Title Space Between
		$this->add_control(
			'skill_box_popup_footer_title_space_bottom',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		//skill box Popup Service List Style
        $this->start_controls_section(
			'skill_box_popup_service_list_style',
			[
				'label' => esc_html__( 'Popup Service List', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//skill box Popup Service List Color
		$this->add_control(
			'skill_box_popup_service_list_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .desc .service-list .service-list-item' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
		//skill box Popup Service List Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_box_popup_service_list_typography',
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .desc .service-list .service-list-item',
			]
		);
		//skill box Popup Service List Space Between
		$this->add_control(
			'skill_box_popup_service_list_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .desc .service-list .service-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 8,
					'right' => 8,
					'bottom' => 8,
					'left' => 8,
				],
			]
		);
		//skill box Popup Service List Border Color
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'skill_box_popup_service_list_border',
				'label' => esc_html__( 'Border', 'wpt-addon' ),
				'selector' => '{{WRAPPER}} .skill-box-wrap .modal .modal-dialog .modal-content .modal-body .portfolio-section .port-content .services .desc .service-list .service-list-item',
			]
		);
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        if ( ! empty( $settings['skill_box_popup_link_website_link']['url'] ) ) {
			$this->add_link_attributes( 'skill_box_popup_link_website_link', $settings['skill_box_popup_link_website_link'] );
		}
		$this->add_render_attribute(
            'wpad_sklii_box_uique_id',
            [
                'id'          => 'skill-box-' . $this->get_id(),
            ]
        );
        $linktarget = $settings[ 'skill_box_popup_link_website_link' ][ 'is_external' ] ? ' target="_blank"' : '';
        $linknofollow = $settings[ 'skill_box_popup_link_website_link' ][ 'nofollow' ] ? ' rel="nofollow"' : '';
        ?>
            <div class="skill-box-wrap">
                <div class="skill-box-content">
					<div class="img">
						<img src="<?php echo $settings['skill_box_image']['url']; ?>" alt="">
					</div>
					<div class="title">
						<h3><?php echo $settings[ 'skill_box_title' ]; ?></h3>
					</div>
					<div class="desc">
						<p><?php echo $settings[ 'skill_box_desc' ]; ?></p>
					</div>
					<div class="wtad-skill-button">
						<a href="#" class="wtad-btn" data-toggle="modal" data-target="#<?php echo 'skill-box-' . $this->get_id(); ?>"><span class="slide-left"><?php echo $settings[ 'skill_box_btn_title' ]; ?></span></a>
					</div>
				</div>
				<div class="modal fade" <?php echo $this->get_render_attribute_string( 'wpad_sklii_box_uique_id' ); ?> tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<div class="image-section">
									<div class="img">
										<img src="<?php echo $settings[ 'skill_box_popup_top_image' ][ 'url' ]; ?>" alt="">
									</div>
									<div class="title">
										<h3><?php echo $settings[ 'skill_box_popup_main_title' ]; ?></h3>
									</div>
								</div>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body p-5">
								<div class="portfolio-section">
									<div class="row">
										<div class="col-md-4">
											<div class="port-image">
												<img src="<?php echo $settings[ 'skill_box_popup_port_image' ][ 'url' ]; ?>" alt="">
											</div>
										</div>
										<div class="col-md-8">
											<div class="port-content">
												<div class="desc">
													<p><?php echo $settings[ 'skill_box_port_desc' ]; ?></p>
												</div>
												<div class="link">
													<a <?php echo $this->get_render_attribute_string( 'skill_box_popup_link_website_link' ); ?> <?php echo $linktarget; ?> <?php echo $linknofollow; ?>>
														<i class="<?php echo $settings[ 'skill_box_popup_link_icon' ]; ?>"></i>
														<span><?php echo $settings[ 'skill_box_popup_link_title' ]; ?></span>
													</a>
												</div>
												<div class="services">
													<div class="title">
														<h3><?php echo $settings[ 'skill_box_popup_service_title' ]; ?></h3>
													</div>
													<div class="desc">
														<ul class="service-list">
															<?php
																if( $settings['skill_box_port_service_list'] ){
																	foreach( $settings['skill_box_port_service_list'] as $item ){
																		?>
																		<li class="service-list-item" <?php echo esc_attr( $item['_id'] ); ?>><?php echo $item['skill_box_port_service_list_name']; ?></li>
																		<?php
																	}
																}
															?>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        <?php
    }

    protected function _content_template() {
		?>
		<#
		var linktarget = settings.skill_box_popup_link_website_link.is_external ? ' target="_blank"' : '';
        var linknofollow = settings.skill_box_popup_link_website_link.nofollow ? ' rel="nofollow"' : '';
		#>
		<div class="skill-box-wrap">
                <div class="skill-box-content">
					<div class="img">
						<img src="{{ settings.skill_box_image.url }}" alt="">
					</div>
					<div class="title">
						<h3>{{{ settings.skill_box_title }}}</h3>
					</div>
					<div class="desc">
						<p>{{{ settings.skill_box_desc }}}</p>
					</div>
					<div class="button">
						<a href="#" class="wtad-btn" data-toggle="modal" data-target="#{{this.get_id}}"><span class="slide-left">{{{ settings.skill_box_btn_title }}}</span></a>
					</div>
				</div>
				<div class="modal fade" {{{ view.getRenderAttributeString( 'wpad_sklii_box_uique_id' ) }}} tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<div class="image-section">
									<div class="img">
										<img src="{{ settings.skill_box_popup_top_image.url }}" alt="">
									</div>
									<div class="title">
										<h3>{{{ settings.skill_box_popup_main_title }}}</h3>
									</div>
								</div>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body p-5">
								<div class="portfolio-section">
									<div class="row">
										<div class="col-md-4">
											<div class="port-image">
												<img src="{{ settings.skill_box_popup_port_image.url }}" alt="">
											</div>
										</div>
										<div class="col-md-8">
											<div class="port-content">
												<div class="desc">
													<p>{{{ settings.skill_box_port_desc }}}</p>
												</div>
												<div class="link">
													<a href="{{ settings.skill_box_popup_link_website_link.url }}" linktarget linknofollow>
														<i class="{{{ settings.skill_box_popup_link_icon }}}"></i>
														<span>{{{ settings.skill_box_popup_link_title }}}</span>
													</a>
												</div>
												<div class="services">
													<div class="title">
														<h3>{{{ settings.skill_box_popup_service_title }}}</h3>
													</div>
													<div class="desc">
														<ul class="service-list">
															<# 
																if( settings.skill_box_port_service_list.length ){
																	_.each( settings.skill_box_port_service_list, function( item ){#>
																		<li class="service-list-item elementor-repeater-item-{{ item._id }}">{{{ item.skill_box_port_service_list_name }}}</li>
																	<#} )
																}
															#>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
		<?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Skill_Box() );