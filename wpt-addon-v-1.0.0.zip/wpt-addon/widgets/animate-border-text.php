<?php
namespace Elementor;

class Animate_Border_Text extends Widget_Base {

    public function get_name() {
        return  'animate-border-text-id';
    }

    public function get_title() {
        return esc_html__( 'Animate Border', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-square';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'animate_border_content_section',
			[
				'label' => esc_html__( 'Animate Border Title', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Title Control
        $this->add_control(
			'animate_border_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Type your title here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,

			]
		);

        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //Animate border content Style Settings
        $this->start_controls_section(
			'animate_border_content_section_style',
			[
				'label' => esc_html__( 'Animate Border Title', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        //Animate border content Padding
		$this->add_control(
			'animate_border_content_padding',
			[
				'label' => esc_html__( 'Content Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wpad-border' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 10,
					'right' => 30,
					'bottom' => 10,
					'left' => 30,
				],
			]
		);
        // Animate Border Background Color
        $this->add_control(
			'animate_border_color',
			[
				'label' => esc_html__( 'Animate Border Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-border i' => 'background: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Animate Border arrow Color
        $this->add_control(
			'animate_border_arrow_color',
			[
				'label' => esc_html__( 'Animate Border Arrow Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-border i:nth-child(5)::before' => 'border-top-color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
		//Animate border content Title Color
		$this->add_control(
			'animate_border_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-border h3' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        //Animate border content Title Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'animate_border_title_typography',
				'selector' => '{{WRAPPER}} .wpad-border h3',
			]
		);
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		$this->add_render_attribute(
            'animate-border_text_id',
            [
                'id'          => 'animate-border-text-' . $this->get_id(),
            ]
        );
        ?>
            <div class="wpad-border" <?php echo $this->get_render_attribute_string( 'animate-border_text_id' ); ?>>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <h3>
                    <?php echo $settings[ 'animate_border_title' ]; ?>
                </h3>
            </div>
        <?php
    }

    protected function _content_template() {
		?>
			<#
			view.addRenderAttribute(
                'animate-border_text_id',
                {
                    'id': 'animate-border-text-id',
                }
            );
			#>
            <div class="animate-border" {{{ view.getRenderAttributeString( 'animate-border_text_id' ) }}}>
				<i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <h3>{{{ settings.animate_border_title }}}</h3>
            </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Animate_Border_Text() );