<?php
namespace Elementor;

class Wpad_Normal_Button extends Widget_Base {

    public function get_name() {
        return  'wpad-normal-button';
    }

    public function get_title() {
        return esc_html__( 'Button', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return ' eicon-button';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpad_normal_btn_content_section',
			[
				'label' => esc_html__( 'Button', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Title Control
        $this->add_control(
			'wpad_normal_btn_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Click Here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Click Here', 'wpt-addon' ),
			]
		);
		// Button url
		$this->add_control(
			'wpad_normal_btn_link',
			[
				'label' => esc_html__( 'Link', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'wpt-addon' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //Animate order content Style Settings
        $this->start_controls_section(
			'wpad_normal_btn_content_section_style',
			[
				'label' => esc_html__( 'Button', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		// Wpad Style Tab
		$this->start_controls_tabs(
			'wpad_normal_btn_style_tabs'
		);
		// Normal Tab
		$this->start_controls_tab(
			'wpad_normal_btn_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);
		// Animate Button Text Color
        $this->add_control(
			'wpad_normal_btn_text_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Animate Button Background Color
        $this->add_control(
			'wpad_normal_btn_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn' => 'background: {{VALUE}}',
				],
				'default' => '#F26C4F'
			]
		);
        // Animate Button Background Color
        $this->add_control(
			'wpad_normal_btn_arrow_color',
			[
				'label' => esc_html__( 'Arrow Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn::before' => 'border-top-color: {{VALUE}}',
				],
				'default' => '#f26c4f'
			]
		);
		//Animate Button Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpad_normal_btn_border',
				'label' => esc_html__( 'Border', 'wpt-addon' ),
				'selector' => '{{WRAPPER}} .wpad-normal-button .wpad-normal-btn',
			]
		);
		$this->end_controls_tab();
		//Hover Tab
        $this->start_controls_tab(
			'wpad_normal_btn_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);
		// Animate Button Text Color
        $this->add_control(
			'wpad_normal_btn_hover_text_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn:hover' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Animate Border Background Color
        $this->add_control(
			'wpad_normal_btn_hover_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn:hover' => 'background: {{VALUE}}',
				],
				'default' => 'rgb(212, 71, 41)'
			]
		);
        // Animate Border Background Color
        $this->add_control(
			'wpad_normal_btn_hover_arrow_color',
			[
				'label' => esc_html__( 'Arrow Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn:hover::before' => 'border-top-color: {{VALUE}}',
				],
				'default' => 'rgb(212, 71, 41)'
			]
		);
		//Animate Button Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpad_normal_btn_hover_border',
				'label' => esc_html__( 'Border', 'wpt-addon' ),
				'selector' => '{{WRAPPER}} .wpad-normal-button .wpad-normal-btn:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
        //Button Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpad_normal_btn_typography',
				'selector' => '{{WRAPPER}} .wpad-normal-button .wpad-normal-btn',
			]
		);
        //Button Padding
		$this->add_control(
			'wpad_normal_btn_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wpad-normal-button .wpad-normal-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 13,
					'right' => 20,
					'bottom' => 13,
					'left' => 20,
				],
			]
		);
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		if( ! empty( $settings[ 'wpad_normal_btn_link' ][ 'url' ] ) ){
			$this->add_link_attributes( 'wpad_normal_btn_link', $settings[ 'wpad_normal_btn_link' ] );
		}
		$norbtnlinktarget = $settings[ 'wpad_normal_btn_link' ][ 'is_external' ] ? ' target="_blank"' : '';
        $norbtnlinknofollow = $settings[ 'wpad_normal_btn_link' ][ 'nofollow' ] ? ' rel="nofollow"' : '';
        ?>
         <div class="wpad-normal-button">
            <a <?php echo $this->get_render_attribute_string( 'wpad_normal_btn_link' ); ?> class="wpad-normal-btn" <?php echo $norbtnlinktarget; ?> <?php echo $norbtnlinknofollow; ?> ><?php echo $settings[ 'wpad_normal_btn_title' ]; ?></a>
         </div>
        <?php
    }

    protected function _content_template() {
		?>
		<# 
		var norbtnlinktarget = settings.wpad_normal_btn_link.is_external ? ' target="_blank"' : '';
        var norbtnlinknofollow = settings.wpad_normal_btn_link.nofollow ? ' rel="nofollow"' : '';
		#>
        <div class="wpad-normal-button">
            <a href="{{ settings.wpad_normal_btn_link }}" class="wpad-normal-btn" norbtnlinktarget norbtnlinknofollow >{{{ settings.wpad_normal_btn_title }}}</a>
         </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpad_Normal_Button() );