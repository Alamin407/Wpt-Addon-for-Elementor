<?php
namespace Elementor;
class Wpad_Testimonial_Slider extends Widget_Base {

    public function get_name() {
        return  'wpad-testimonial-slider-id';
    }

    public function get_title() {
        return esc_html__( 'Testimonial Slider', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-slides';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpad_testimonial_content_section',
			[
				'label' => esc_html__( 'Testimonial', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Testimonial List
        $repeater = new \Elementor\Repeater();
        // Testimonial Slider Icon
        $repeater->add_control(
			'wpad_testimonial_icon', [
				'label' => esc_html__( 'Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'fa-solid fa-quote-right' , 'wpt-addon' ),
				'label_block' => true,
			]
		);
        // Testimonial Slider Content
        $repeater->add_control(
			'wpad_testimonial_content', [
				'label' => esc_html__( 'Content', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'List Content' , 'wpt-addon' ),
				'show_label' => false,
			]
		);
        // Testimonial Slider Image
        $repeater->add_control(
            'wpad_testimonial_image',
            [
                'label'   => __( 'Image', 'my-elementor-widget' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
        );
        // Testimonial Slider Title
        $repeater->add_control(
			'wpad_testimonial_title', [
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'wpt-addon' ),
				'label_block' => true,
			]
		);
        // Testimonial Slider Subtitle
        $repeater->add_control(
			'wpad_testimonial_subtitle', [
				'label' => esc_html__( 'Subtitle', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Subtitle' , 'wpt-addon' ),
				'label_block' => true,
			]
		);
        // Testimonial Slider List
        $this->add_control(
			'wpad_testimonial_list',
			[
				'label' => esc_html__( 'Testimonial Items', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'wpad_testimonial_title' => esc_html__( 'Title #1', 'wpt-addon' ),
						'wpad_testimonial_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
					[
						'wpad_testimonial_title' => esc_html__( 'Title #2', 'wpt-addon' ),
						'wpad_testimonial_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
				],
				'title_field' => '{{{ wpad_testimonial_title }}}',
			]
		);
        $this->end_controls_section();
        // Slider Settings
        $this->start_controls_section(
			'wpad_testimonial_slider_settings',
			[
				'label' => esc_html__( 'Slider Settings', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // show Loop
        $this->add_control(
            'loop',
            [
                'label' => __( 'Loop', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );

        // show Dots
        $this->add_control(
            'dots',
            [
                'label' => __( 'Dots', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => false,
            ]
        );

        // Show Navs
        $this->add_control(
            'navs',
            [
                'label' => __( 'Navs', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );
        // Show Autoplay
        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Autoplay', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );
        // Autoplay Hover Pause
        $this->add_control(
            'pause',
            [
                'label' => __( 'Pause On Hover', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );

        // Margin
        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 10,
                'placeholder' => __( 'Enter the margin between to slides', 'plugin-domain' ),
            ]
        );
        // Autoplay Speed
        $this->add_control(
            'speed',
            [
                'label' => __( 'Autoplay Speed', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 800,
                'placeholder' => __( 'Enter the Autoplay Speed', 'plugin-domain' ),
            ]
        );
        $this->end_controls_section();

        $this->style_tab();
    }

    private function style_tab() {
        //Animate order content Style Settings
        $this->start_controls_section(
			'wpad_testimonial_icon_section_style',
			[
				'label' => esc_html__( 'Icon', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        // Icon Width
        $this->add_control(
			'wpad_testimonial_icon_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Height
        $this->add_control(
			'wpad_testimonial_icon_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 53,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Height
        $this->add_control(
			'wpad_testimonial_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Height
        $this->add_control(
			'wpad_testimonial_icon_margin',
			[
				'label' => esc_html__( 'Spece Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Background
        $this->add_control(
			'wpad_testimonial_icon_background',
			[
				'label' => esc_html__( 'Icon Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon' => 'background: {{VALUE}}',
				],
                'default' => '#F26C4F'
			]
		);
        // Icon Color
        $this->add_control(
			'wpad_testimonial_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon i' => 'color: {{VALUE}}',
				],
                'default' => '#fff'
			]
		);
        // Icon Arrow Color
        $this->add_control(
			'wpad_testimonial_icon_arrow_color',
			[
				'label' => esc_html__( 'Arrow Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-head .icon::before' => 'border-top-color: {{VALUE}}',
				],
                'default' => '#f26c4f'
			]
		);
		$this->end_controls_section();
        // Testimonial Description
        $this->start_controls_section(
			'wpad_testimonial_desc_section_style',
			[
				'label' => esc_html__( 'Description', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        // Testimonial Description Color
        $this->add_control(
			'wpad_testimonial_desc_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-body p' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
        // Testimonial Description Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpad_testimonial_desc_typography',
                'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-body p',
			]
		);
        // Testimonial Description Spacing
        $this->add_control(
			'wpad_testimonial_desc_margin',
			[
				'label' => esc_html__( 'Spece Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-body' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
        // Testimonial Image
        $this->start_controls_section(
			'wpad_testimonial_img_section_style',
			[
				'label' => esc_html__( 'Image', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        // Testimonial Image Width
        $this->add_control(
			'wpad_testimonial_img_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 110,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-img .testm-person-avater' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Image Height
        $this->add_control(
			'wpad_testimonial_img_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 110,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-img .testm-person-avater' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Image Margin
        $this->add_control(
			'wpad_testimonial_img_margin',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-img .testm-person-avater' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Image Border Radius
        $this->add_control(
			'wpad_testimonial_img_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-img .testm-person-avater img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => '%',
					'top' => 50,
					'right' => 50,
					'bottom' => 50,
					'left' => 50,
				],
			]
		);
        $this->end_controls_section();
        // Testimonial Person
        $this->start_controls_section(
			'wpad_testimonial_person_section_style',
			[
				'label' => esc_html__( 'Person', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        // Testimonial Person Title Heading
        $this->add_control(
            'wpad_testimonial_person_title_heading',
            [
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
        );
        // Testimonial Person Name
        $this->add_control(
			'wpad_testimonial_person_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-name .name .person-name' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
        // Testimonial Description Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpad_testimonial_person_title_typography',
                'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-name .name .person-name',
			]
		);
        // Testimonial Description Spacing
        $this->add_control(
			'wpad_testimonial_person_title_margin',
			[
				'label' => esc_html__( 'Spece Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-name .name .person-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Person Title Heading
        $this->add_control(
            'wpad_testimonial_person_subtitle_heading',
            [
                'label' => __( 'Subtitle', 'wpt-addon' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        // Testimonial Person Name
        $this->add_control(
			'wpad_testimonial_person_subtitle_color',
			[
				'label' => esc_html__( 'SubTitle Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-name .name .person-title' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
        // Testimonial Description Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpad_testimonial_person_subtitle_typography',
                'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .item .testm-footer .testm-person-name .name .person-title',
			]
		);
        $this->end_controls_section();
        // Testimonial Nav
        $this->start_controls_section(
			'wpad_testimonial_nav_section_style',
			[
				'label' => esc_html__( 'Nav', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        // Testimonial Nav Width
        $this->add_control(
			'wpad_testimonial_nav_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Nav Width
        $this->add_control(
			'wpad_testimonial_nav_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Nav Icon Size
        $this->add_control(
			'wpad_testimonial_nav_icon_Size',
			[
				'label' => esc_html__( 'Icon Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next i, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Testimonial Nav Style Tab
        $this->start_controls_tabs(
			'wpad_testimonial_nav_style_tabs'
		);
        // Testimonial Nav Normal Tab
        $this->start_controls_tab(
			'wpad_testimonial_nav_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);
        // Testimonial Nav Normal Icon Color
        $this->add_control(
			'wpad_testimonial_nav_normal_icon_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next i, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev i' => 'color: {{VALUE}}',
				],
				'default' => '#020312'
			]
		);
        // Testimonial Nav Normal Background
        $this->add_control(
			'wpad_testimonial_nav_normal_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev' => 'background: {{VALUE}}',
				],
				'default' => '#9D9EA3'
			]
		);
        $this->end_controls_tab();
        // Testimonial Nav Hover Tab
        $this->start_controls_tab(
			'wpad_testimonial_nav_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);
        // Testimonial Nav Hover Icon Color
        $this->add_control(
			'wpad_testimonial_nav_hover_icon_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next:hover i, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev:hover i' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        //Testimonial Nav Hover Background
        $this->add_control(
			'wpad_testimonial_nav_hover_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next:hover, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev:hover' => 'background: {{VALUE}}',
				],
				'default' => 'rgba(25, 25, 25, .8)'
			]
		);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //Testimonial Nav Border Radius
        $this->add_control(
			'wpad_testimonial_nav_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-next, .wpad-testimonial-slider .wpad-testimonial .owl-nav .owl-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => '%',
					'top' => 50,
					'right' => 50,
					'bottom' => 50,
					'left' => 50,
				],
			]
		);
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute(
            'wpad_tesitimonial_carousel_options',
            [
                'id'          => 'testimonial-slider-' . $this->get_id(),
                'data-loop'   => $settings[ 'loop' ],
                'data-dots'   => $settings[ 'dots' ],
                'data-navs'   => $settings[ 'navs' ],
                'data-margin' => $settings[ 'margin' ],
                'data-autoplay' => $settings[ 'autoplay' ],
                'data-pause' => $settings[ 'pause' ],
                'data-speed' => $settings[ 'speed' ],
            ]
        );
        ?>
         <div class="wpad-testimonial-slider">
            <?php
                if( $settings[ 'wpad_testimonial_list' ] ){
                    ?>
                        <div class="owl-carousel owl-theme wpad-testimonial" <?php echo $this->get_render_attribute_string( 'wpad_tesitimonial_carousel_options' ); ?>>
                        <?php
                        foreach( $settings[ 'wpad_testimonial_list' ] as $items ){
                            ?>
                                <div class="item">
                                    <div class="testm-head">
                                        <div class="icon">
                                            <i class="<?php echo $items[ 'wpad_testimonial_icon' ]; ?>"></i>
                                        </div>
                                    </div>
                                    <div class="testm-body">
                                        <p class="desc"><?php echo $items[ 'wpad_testimonial_content' ]; ?></p>
                                    </div>
                                    <div class="testm-footer">
                                        <div class="testm-person-img">
                                            <div class="testm-person-avater">
                                                <img src="<?php echo $items[ 'wpad_testimonial_image' ][ 'url' ] ?>" alt="">
                                            </div>
                                        </div>
                                        <div class="testm-person-name">
                                            <div class="name">
                                                <h3 class="person-name"><?php echo $items[ 'wpad_testimonial_title' ]; ?></h3>
                                                <h6 class="person-title"><?php echo $items[ 'wpad_testimonial_subtitle' ]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                        ?>
                    </div>
                    <?php
                }
            ?>
         </div>
        <?php
    }

    protected function _content_template() {
		?>
        <#
            view.addRenderAttribute(
                'wpad_tesitimonial_carousel_options',
                {
                    'id' : 'testimonial-slider-id',
                    'data-loop' : settings.loop,
                    'data-dots' : settings.dots,
                    'data-navs' : settings.navs,
                    'data-margin' :settings.margin,
                    'data-autoplay' : settings.autoplay,
                    'data-pause' : settings.pause,
                    'data-speed' : settings.speed,
                }
            );
        #>
        <div class="wpad-testimonial-slider">
            <# if ( settings.wpad_testimonial_list.length ) { #>
                <div class="owl-carousel owl-theme wpad-testimonial" {{{ view.getRenderAttributeString( 'wpad_tesitimonial_carousel_options' ) }}}>
                <# _.each( settings.wpad_testimonial_list, function( items ) { #>
                    <div class="item">
                        <div class="testm-head">
                            <div class="icon">
                                <i class="{{{ items.wpad_testimonial_icon }}}"></i>
                            </div>
                        </div>
                        <div class="testm-body">
                            <p class="desc">{{{ items.wpad_testimonial_content }}}</p>
                        </div>
                        <div class="testm-footer">
                            <div class="testm-person-img">
                                <div class="testm-person-avater">
                                    <img src="{{ items.wpad_testimonial_image.url }}" alt="">
                                </div>
                            </div>
                            <div class="testm-person-name">
                                <div class="name">
                                    <h3 class="person-name">{{{ items.wpad_testimonial_title }}}</h3>
                                    <h6 class="person-title">{{{ items.wpad_testimonial_subtitle }}}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                <# }); #>
                </div>
            <# } #>
        </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpad_Testimonial_Slider() );