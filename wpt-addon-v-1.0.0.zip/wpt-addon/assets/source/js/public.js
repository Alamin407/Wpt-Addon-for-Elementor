;( function( $ ){
    "use strict";
    // Testimonial Carousel
    var testimonialCarousel = function( $scope, $ ){
        var prvIcon = '<i class="fa-solid fa-chevron-left"></i>';
        var nxtIcon = '<i class="fa-solid fa-chevron-right"></i>';
        var $_this = $scope.find( '.wpad-testimonial' );
        var $currentID = '#'+$_this.attr( 'id' ),
            $loop   = $_this.data( 'loop' ),
            $dots   = $_this.data( 'dots' ),
            $navs   = $_this.data( 'navs' ),
            $autoplay   = $_this.data( 'autoplay' ),
            $pause   = $_this.data( 'pause' ),
            $margin   = $_this.data( 'margin' ),
            $speed   = $_this.data( 'speed' );
        
            var owl = $( $currentID );
            owl.owlCarousel({
                loop: $loop ,
                margin: $margin,
                nav: $navs,
                autoplay: $autoplay,
                autoplayHoverPause: $pause,
                smartSpeed: $speed,
                dots: $dots,
                navText: [
                    prvIcon,
                    nxtIcon,
                ],
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:1
                    },
                    1000:{
                        items:1
                    }
                }
            });
    }

    var animateborder = function( $scope, $ ){
        var $_this = $scope.find( '.wpad-border' );
        var $currentID = '#'+$_this.attr( 'id' );
        var $posTop = $( $currentID ).offset();
        $( $currentID ).each( function(){
            $(window).scroll(function(){
                if( $( this ).scrollTop() <= $posTop.top  ){
                    $( $currentID ).each( function(){
                        $( this ).addClass( 'in' );
                    } );
                } else{
                    $( $currentID ).each( function(){
                        $( this ).removeClass( 'in' );
                    } );
                }
            } );
        } );
        
    }

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/wpad-testimonial-slider-id.default', testimonialCarousel);
    });
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/animate-border-text-id.default', animateborder);
    });

} )( jQuery );